import sys 
# Takes first name and last name via command 
# line arguments and then display them 
print(sys.argv[1])

# save the script as hello.py 
